<?php
/*
Template Name: Legal
*/
get_header();?>

Here I Am

<?php get_footer(); ?>