<?php
/*
Template Name: Terms and Conditions
*/
get_header();?>

Here I Am

<?php get_footer(); ?>