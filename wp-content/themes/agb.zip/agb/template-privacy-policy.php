<?php
/*
Template Name: Privacy Policy
*/
get_header();?>

Here I Am

<?php get_footer(); ?>