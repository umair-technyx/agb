<?php
/*
Template Name: Get In Touch
*/
get_header();?>

Here I Am

<?php get_footer(); ?>