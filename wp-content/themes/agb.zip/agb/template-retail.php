<?php
/*
Template Name: Retail Banking
*/
get_header();?>

Here I Am

<?php get_footer(); ?>