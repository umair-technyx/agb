<?php
/*
Template Name: Cookie Declaration
*/
get_header();?>

Here I Am

<?php get_footer(); ?>